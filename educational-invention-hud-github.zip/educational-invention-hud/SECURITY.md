# Security policy

## Reporting

Do not publish API keys, personal scan reports, or private system information in issues. For a real deployment, provide a private reporting channel in the repository settings.

## Current limitations

This is an educational prototype. Do not expose the server publicly without authentication, deployment-level secret management, monitoring, and abuse controls. The frontend currently evaluates generated JavaScript for canvas demonstrations; the basic token filter is not a security boundary. Review generated code and avoid sensitive browser sessions while testing.
