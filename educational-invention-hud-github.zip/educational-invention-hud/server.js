import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const GEMINI_API_KEY = process.env.GEMINI_API_KEY?.trim();
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

app.disable('x-powered-by');
app.use(helmet({
  // This HUD contains inline UI handlers and a canvas-code demo. A strict CSP requires
  // refactoring those features; do not treat this baseline as a complete sandbox.
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '24kb', strict: true }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, aiConfigured: Boolean(GEMINI_API_KEY), mode: GEMINI_API_KEY ? 'gemini' : 'offline' });
});

app.post('/api/generate', async (req, res) => {
  res.set('Cache-Control', 'no-store');
  if (!GEMINI_API_KEY) return res.status(503).json({ error: 'AI is not configured. Add GEMINI_API_KEY to your local .env file.' });
  const { systemInstruction, prompt } = req.body ?? {};
  if (typeof systemInstruction !== 'string' || typeof prompt !== 'string' || !prompt.trim()) {
    return res.status(400).json({ error: 'Expected systemInstruction and prompt strings.' });
  }
  if (systemInstruction.length > 12_000 || prompt.length > 4_000) {
    return res.status(413).json({ error: 'Request is too long.' });
  }
  try {
    const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: AbortSignal.timeout(30_000),
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 }
      })
    });
    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      // Do not relay upstream payloads that could contain internal diagnostics or secrets.
      return res.status(upstream.status === 429 ? 429 : 502).json({ error: upstream.status === 429 ? 'AI provider rate limit reached. Try later.' : 'AI provider request failed.' });
    }
    const text = payload?.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('\n').trim();
    if (!text) return res.status(502).json({ error: 'AI provider returned no text.' });
    return res.json({ text });
  } catch (_error) {
    return res.status(504).json({ error: 'AI provider timed out or could not be reached.' });
  }
});

const publicDir = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(publicDir, { index: 'index.html', dotfiles: 'deny', etag: true, maxAge: '1h' }));
app.use((_req, res) => res.status(404).send('Not found'));
app.listen(PORT, () => console.log(`Educational Invention HUD running at http://localhost:${PORT}`));
