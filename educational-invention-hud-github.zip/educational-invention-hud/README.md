# Educational Invention HUD

A browser-based science-fiction-inspired HUD for learning system design, canvas visualizations, and early-stage invention thinking. Concept scores and demos are educational only; they do not prove scientific validity or worldwide novelty.

## Features

- Interactive HUD widgets and canvas visualizations
- Educational invention lab and generated concept dossiers
- Optional Gemini-powered generation through a server-side API proxy
- API key stays in the local server environment, not in browser storage or source code
- Offline/local fallback when the AI service is not configured

## Requirements

- Node.js 20 or newer
- A Gemini API key only if you want cloud AI features

## Run locally

1. Clone or download this repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env`.
4. Put your own key in `.env` as `GEMINI_API_KEY=...`. Do not share or commit this file.
5. Start the server:
   ```bash
   npm start
   ```
6. Open http://localhost:3000. Do not open `index.html` directly as a `file://` URL; AI requests require the local server.

## Publish to GitHub

Upload the project files to a repository, but **never upload `.env`, API keys, scan reports, or private data**. `.gitignore` excludes these by default. For public hosting, configure `GEMINI_API_KEY` as a server-side environment secret on a hosting provider that runs Node.js. GitHub Pages is static hosting and cannot run this API proxy by itself.

## Security notes

- The key is read only by `server.js` from the environment and is never returned by the API.
- API endpoint has JSON size limits, basic request validation, and rate limiting. Add authentication before exposing a public deployment to prevent strangers from consuming your AI quota.
- This is a learning project, not a hardened production service.
- The HUD can compile and execute generated canvas JavaScript using `new Function`. A lightweight token filter is not a secure sandbox. Review generated code, run locally, and do not use it with sensitive browser sessions. For public/untrusted use, move visual execution into a tightly sandboxed iframe or replace dynamic code execution with declarative drawing commands.
- The application is designed for educational use. Do not use it for medical, safety-critical, or other high-stakes decisions.

## Repository layout

```text
index.html       HUD frontend
server.js        Express server and Gemini API proxy
package.json     Dependencies and run scripts
.env.example    Environment variable template (no secret)
.gitignore      Ignore rules for secrets and generated files
README.md       Setup and security instructions
SECURITY.md     Security reporting and limitations
LICENSE         MIT license
```
